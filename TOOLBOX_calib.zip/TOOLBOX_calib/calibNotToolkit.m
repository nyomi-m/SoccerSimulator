addpath('../TOOLBOX_calib');

%clear;

%calib_gui;
%
% Select: standard mode
%
% Select: Image names
%   basename: c3xz
%   image format: t
%
% Select: extract grid corners
%   wintx, winty: defaults
%   automatic counting: defaults
%   select corners (be careful around the big black circle)
%   x squares: 15
%   y squares: 9
%   dx: 0.5
%   dy: 0.5
%
%   repeat for each image
% 
% My corners are saved in "extracted_corners.mat"
%
% load('newCamCorners.mat');
load('oldCamCorners.mat');

ip = [x_1 x_2 x_3 x_4 x_5];
X_1 = [X_1(1:2,:);   zeros(1,size(X_1,2))];
X_2 = [X_2(1:2,:); -1*ones(1,size(X_2,2))];
X_3 = [X_3(1:2,:); -2*ones(1,size(X_3,2))];
X_4 = [X_4(1:2,:); -3*ones(1,size(X_4,2))];
X_5 = [X_5(1:2,:); -4*ones(1,size(X_5,2))];
wp = [X_1 X_2 X_3 X_4 X_5];

n_ima = 1;

x_1 = ip;
X_1 = wp;

% Image size: (may or may not be available)
nx = 1129;
ny = 753;

% No calibration image is available (only the corner coordinates)
no_image = 1;

% Set the toolbox not to prompt the user (choose default values)
dont_ask = 1;

% Run the main calibration routine:
go_calib_optim;

% Shows the extrinsic parameters:
ext_calib;

% Reprojection on the original images:
reproject_calib;

% Set the toolbox to normal mode of operation again:
dont_ask =  0;
